<template>
    <div>
        <div class="container">
            <el-container>
                <el-aside width="80%"> <img src="../assets/img/login.jpg" class="user-avator" alt /></el-aside>
                <el-main>
                    <el-container>
                        <el-main>
                            <h2>关于本馆</h2>
                            <p>在本馆中，用户可以搜索、浏览感兴趣的图书，并预约、借还。工作人员可以管理图书信息、处理用户的借还、预约。管理员可以对工作人员进行增删操作。</p>
                            <h2>制作团队：</h2>
                            <p>前端：邹志凯、何潇龙</p>
                            <p>后端：孙宏伟、谷知峰、聂文浩</p>
                            <h2>如有问题请联系：</h2>
                            <h3>a2269713951@163.com</h3>
                        </el-main>
                    </el-container>
                </el-main>
            </el-container>
        </div>
    </div>
</template>