module.exports = {
    outputDir: 'dist',
    assetsDir:'static',
    publicPath:'/',
}